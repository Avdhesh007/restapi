from __future__ import unicode_literals
from django.db import models


# Create your models here.

class Musician(models.Model):
    first_name=models.CharField(max_length=15)
    last_name=models.CharField(max_length=15)
    instrument=models.CharField(max_length=15)

    def __unicode__(self):
        return self.first_name

class Album(models.Model):
    artist=models.ForeignKey(Musician,on_delete=models.CASCADE,related_name='album_musician',null=True,blank=True)
    name=models.CharField(max_length=15)
    release_date=models.DateField()
    num_stars=models.IntegerField()


