from django.apps import AppConfig


class Restapp10Config(AppConfig):
    name = 'restapp10'
