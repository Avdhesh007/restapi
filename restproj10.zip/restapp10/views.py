from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework import generics

# Create your views here.

class MusicianListView(generics.ListCreateAPIView):
    queryset = Musician.objects.all()
    serializer_class = MusicianSerializers

class MusicianView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MusicianSerializers
    queryset = Musician.objects.all()

class AlbumListView(generics.ListCreateAPIView):
    serializer_class = AlbumSerializers
    queryset = Album.objects.all()

class AlbumView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = AlbumSerializers
    queryset = Album.objects.all()
