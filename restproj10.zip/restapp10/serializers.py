from .models import *
from rest_framework import serializers,fields

class AlbumSerializers(serializers.ModelSerializer):
    class Meta:
        model=Album
        fields=('id','artist','name','release_date','num_stars')

class MusicianSerializers(serializers.ModelSerializer):
    album_musician=AlbumSerializers(read_only=True,many=True)
    class Meta:
        model=Musician
        fields=('id','first_name','last_name','instrument','album_musician')
