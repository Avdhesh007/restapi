"""restproj10 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from restapp10 import views
from rest_framework.authtoken.views import obtain_auth_token

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^api/musician/$',views.MusicianListView.as_view()),
    url(r'^api/musician/(?P<pk>\d+)$',views.MusicianView.as_view()),
    url(r'^api/albums/$',views.AlbumListView.as_view()),
    url(r'^api/albums/(?P<pk>\d+)$',views.AlbumView.as_view()),
    url(r'^api-token-auth/$',obtain_auth_token),

]

#python manage.py createsuperuser --username vitor --email vitor@example.com
#http http://127.0.0.1:8000/authapp/hello/ "Authorization: Token 	c13a6570f649e3ec20f865763daa623c3fb707be"
#http post http://127.0.0.1:8000/authapp/api-token-auth/ username=avdhesh007 password=authapp@
#http --json POST http://127.10.0.1:8000/authapp/products/ pid="1004" pname="iphonex" pcost="9999" pmfdt="2018-02-16" pexpdt="2019-02-16" Authorization: "Token c13a6570f649e3ec20f865763daa623c3fb707be"
#http --json DELETE http://127.0.0.1:8000/authapp/products/101/ Authorization: "Token c13a6570f649e3ec20f865763daa623c3fb707be"
