from django.shortcuts import render
from .models import Product
from .serializers import ProductSerializer
from django.http import HttpResponse
from rest_framework.renderers import JSONRenderer


# Create your views here.
def input(request):
    return render(request,'input.html')
def insert(request):
    pid=int(request.GET['t1'])
    pname=request.GET['t2']
    pcost=float(request.GET['t3'])
    pmfdt=request.GET['t4']
    pexpdt=request.GET['t5']
    f=Product(pid,pname,pcost,pmfdt,pexpdt)
    f.save()
    return render(request,'links.html')
def display(request):
    recs=Product.objects.all()
    return render(request,'display.html',{'records':recs})
def productapi(request):
    data=Product.objects.all()
    serializer=ProductSerializer(data,many=True)
    return HttpResponse(JSONRenderer().render(serializer.data))


