from django.apps import AppConfig


class Restapp3Config(AppConfig):
    name = 'restapp3'
