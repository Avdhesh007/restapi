from rest_framework import serializers
class ProductSerializer(serializers.Serializer):
    pid=serializers.IntegerField()
    pname=serializers.CharField()
    pcost=serializers.IntegerField()
    pmfdt=serializers.DateField()
    pexpdt=serializers.DateField()


