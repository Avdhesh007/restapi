from django.shortcuts import render
from datetime import datetime
from .serializers import CommentSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.
class Comment:
    def __init__(self,email,content,created=None):
        self.email=email
        self.content=content
        self.created=created or datetime.now()

def myapi(request):
        comment=Comment(email='abc@example.com',content='foo bar')
        serializer=CommentSerializer(comment)
        return HttpResponse( JSONRenderer().render(serializer.data))


