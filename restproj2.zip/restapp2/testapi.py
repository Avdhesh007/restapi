import requests
url='http://127.0.0.1:8000/restapp2/display'
response=requests.get(url)
d=(response.json())
print(d)
