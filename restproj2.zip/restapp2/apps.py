from django.apps import AppConfig


class Restapp2Config(AppConfig):
    name = 'restapp2'
