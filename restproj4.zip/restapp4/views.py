from django.shortcuts import render
from .models import Product
from .serializers import ProductSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.
def input(request):
    return render(request,'input.html')
def insert(request):
    pid1 = int(request.GET['t1'])
    pname1 = request.GET['t2']
    pcost1 = float(request.GET['t3'])
    pmfdt1 = request.GET['t4']
    pexpdt1 = request.GET['t5']
    sp=Product(pid=pid1,pname=pname1,pcost=pcost1,pmfdt=pmfdt1,pexpdt=pexpdt1)
    sp.save()

    return render(request,'links.html')
def display(request):
    data=Product.objects.all()
    return render(request,'display.html',{'records':data})
def productapi(request):
    data=Product.objects.all()
    serializer=ProductSerializer(data,many=True)
    return JsonResponse(serializer.data)
class JsonResponse(HttpResponse):
    def __init__(self,data,**kwargs):
        content=JSONRenderer().render(data)
        kwargs['content_type']='application/json'
        super(JsonResponse,self).__init__(content,**kwargs)



