from django.apps import AppConfig


class Restapp4Config(AppConfig):
    name = 'restapp4'
