from django.contrib import admin
from authapp.models import Product
from authapp.models1 import Entry,Author,Blog
# Register your models here.
admin.site.register(Product)
admin.site.register(Entry)
admin.site.register(Blog)
admin.site.register(Author)

