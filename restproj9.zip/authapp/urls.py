from django.conf.urls import url
from .import views
from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token
app_name='authapp'

urlpatterns=[
    url(r'^$',views.input,name='input'),
    url(r'^insert$',views.insert,name='insert'),
    url(r'^display$',views.display,name='display'),
    url(r'^products/$', views.ProductList.as_view()),
    url(r'^products/( ?p<pk>[0-9]+)$', views.ProductList1.as_view()),
    path('api-token-auth/', obtain_auth_token, name='api_token_auth'),
    path('hello/', views.HelloView.as_view(), name='hello'),

]
#python manage.py createsuperuser --username vitor --email vitor@example.com
#http http://127.0.0.1:8000/authapp/hello/ "Authorization: Token 	c13a6570f649e3ec20f865763daa623c3fb707be"
#http post http://127.0.0.1:8000/authapp/api-token-auth/ username=avdhesh007 password=authapp@
#http --json POST http://127.10.0.1:8000/authapp/products/ pid="1004" pname="iphonex" pcost="9999" pmfdt="2018-02-16" pexpdt="2019-02-16" Authorization: "Token c13a6570f649e3ec20f865763daa623c3fb707be"
#http --json DELETE http://127.0.0.1:8000/authapp/products/101/ "Authorization: Token c13a6570f649e3ec20f865763daa623c3fb707be"
