from django.shortcuts import render
from .serializers import ProductSerializer,Product
from .models1 import Blog,Author,Entry
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from .permissions import *
from rest_framework.permissions import IsAuthenticated
# Create your views here.
def input(request):
    return render(request,'input.html')

def insert(request):
    pid=int(request.GET['t1'])
    pname=request.GET['t2']
    pcost=request.GET['t3']
    pmfdt=request.GET['t4']
    pexpdt=request.GET['t5']
    f=Product(pid,pname,pcost,pmfdt,pexpdt)
    f.save()
    return render(request,'links.html')

def display(request):
    recs=Product.objects.all()
    return render(request,'display.html',{'records':recs})

class ProductList(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = (IsAdminOrReadOnly,)

class ProductList1(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = (IsAdminOrReadOnly,)

class HelloView(APIView):
    permission_classes = (IsAuthenticated,)             # <-- And here

    def get(self, request):
        content = {'message': 'Hello, World!'}
        return Response(content)
