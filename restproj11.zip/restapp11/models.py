from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Product(models.Model):
    pid=models.IntegerField(primary_key=True)
    pname=models.CharField(max_length=15)
    pcost=models.DecimalField(max_digits=4,decimal_places=2)
    pmfdt=models.DateField()
    pexpdt=models.DateField()

class Review(models.Model):
    #rid=models.IntegerField(primary_key=True)
    product=models.ForeignKey(Product,on_delete=models.CASCADE,related_name='reviews')
    title=models.CharField(max_length=255)
    review=models.TextField()
    rating=models.IntegerField()
    created_by=models.ForeignKey(User,null=True,on_delete=models.CASCADE)


