from django.conf.urls import url
from .import views
app_name='restapp11'

urlpatterns=[
    url(r'^productscreate/',views.ProductsCreate.as_view()),
    url(r'^reviewcreate/',views.ReviewCreate.as_view()),
    url(r'^products/(?P<pk>\d+)$',views.ProductList.as_view()),
    url(r'^products1/(?P<pk>[0-9]+)/reviews/(?P<review_id>[0-9]+)/$',views.ReviewDetail.as_view()),
]
