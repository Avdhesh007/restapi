from django.apps import AppConfig


class Restapp11Config(AppConfig):
    name = 'restapp11'
