from django.shortcuts import render
from rest_framework import generics
from .models import Product,Review
from .serializers import ProductSerializres,ReviewSerializers
from .permissions import IsAdminOrReadOnly,IsOwnerOrReadOnly


# Create your views here.
class ProductList(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializres
    permission_classes = (IsAdminOrReadOnly,)

class ProductsCreate(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializres
    permission_classes = (IsAdminOrReadOnly,)

class ReviewDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializers
    permission_classes = (IsOwnerOrReadOnly,)

class ReviewCreate(generics.ListCreateAPIView):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializers
    permission_classes = (IsOwnerOrReadOnly,)


