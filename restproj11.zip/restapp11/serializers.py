from rest_framework import serializers
from .models import Product,Review


class ProductSerializres(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields=('pid','pname','pcost','pmfdt','pexpdt')

class ReviewSerializers(serializers.ModelSerializer):
    created_by=serializers.ReadOnlyField(source='created_by.username'),
    class Meta:
        model=Review
        fields=('product','title','review','rating','created_by')

